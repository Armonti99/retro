<?php

    return array(

        'hooks' => array('user_delete')

    );
