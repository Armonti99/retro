<?php

    return array(

        'hooks' => array(
            'menu_admin',
            'user_login',
            'admin_confirm_login',
            'grid_admin_content_items_args'
        )

    );
