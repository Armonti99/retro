<?php
/**
 * Данный файл позволяет переопределить URL любого компонента
 * Документация: http://docs.instantcms.ru/manual/settings/rewriting
 */
